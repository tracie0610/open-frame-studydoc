=======================================================
Jacobgen basic readme.txt  
Most documentation is being moved to the docs directory
=======================================================

Description
-----------
Jacobgen generates java class wrappers microsoft DLLs
that make them callable from java programs.  The class
are built on top of the Jacob (Java-COM Bridge) project.
This library is ONLY useful if you are running Jacob.

Running Jacobgen
----------------
See docs/run_jacobgen.bat for an example script that
runs jacobgen

ReleaseNotes and Technical Issues
---------------------------------
see docs/ReleaseNotes.html

Credits
-------
see docs/credits.txt

History
-------
See docs/ReleaseNotes.html
  